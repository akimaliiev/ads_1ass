public class Main {
    public static void main(String[] args) {
        MyArrayList<String> list = new MyArrayList<>();
    }
}